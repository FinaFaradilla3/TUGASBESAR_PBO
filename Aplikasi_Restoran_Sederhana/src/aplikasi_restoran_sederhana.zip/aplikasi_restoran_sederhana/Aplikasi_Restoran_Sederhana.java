/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi_restoran_sederhana;

/**
 *
 * @author ZenBook
 */
public class Aplikasi_Restoran_Sederhana {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        koneksi k = new koneksi();
//        k.connect();
    Login l = new Login();
        l.setVisible(true);

    }
    
}
